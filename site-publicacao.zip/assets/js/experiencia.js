/* Recursos da entrega final: catálogo inicial e montador de combinação. */
(() => {
 'use strict';
 const produtos = window.PRODUTOS || [];
 const dinheiro = valor => (valor / 100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
 const home = document.querySelector('[data-home-products]');
 const fotos = {acai:['acai-paraense.jpg','Açaí puro servido na tigela'],tapioca:['tapioca-braganca.jpg','Farinha de tapioca de Bragança, Pará'],farinha:['farinha-paraense.jpg','Farinha de mandioca servida em uma cuia']};
 const descricoes = {acai:'O protagonista da mesa. Puro, roxo e paraense.',tapioca:'Grãos leves e crocantes para encontrar a polpa.',farinha:'A textura que completa esse encontro de sabores.'};
 if (home) home.replaceChildren(...produtos.map(produto => {
  const article=document.createElement('article');article.className='home-product';
  const link=document.createElement('a');link.href='paginas/produtos.html#catalogo';
  const picture=document.createElement('div');picture.className='image-wrap';
  const image=document.createElement('img');const photo=fotos[produto.id]||fotos.farinha;
  image.src=`assets/imagens/${photo[0]}`;image.alt=photo[1];image.width=600;image.height=450;image.loading='lazy';
  const badge=document.createElement('span');badge.className='category-tag';badge.textContent=produto.categoria==='acai'?'O ESSENCIAL':'PARA ACOMPANHAR';
  picture.append(image,badge);
  const title=document.createElement('h3');title.textContent=produto.nome;
  const desc=document.createElement('p');desc.textContent=descricoes[produto.id]||produto.descricao;
  const bottom=document.createElement('div');bottom.className='home-product-bottom';
  const price=document.createElement('strong');price.textContent=`A partir de ${dinheiro(Math.min(...produto.opcoes.map(opcao=>opcao.preco)))}`;
  const cta=document.createElement('span');cta.textContent='Escolher';bottom.append(price,cta);
  link.append(picture,title,desc,bottom);article.append(link);return article;
 }));
 const form=document.querySelector('#combo-form');
 if(form){
  const chave='acai-do-para-carrinho-v3';const status=document.querySelector('#combo-status');
  const selecionados=()=>[
   {id:'acai',opcao:form.elements.acai.value,quantidade:1},
   ...(form.elements.tapioca.checked?[{id:'tapioca',opcao:'pacote',quantidade:1}]:[]),
   ...(form.elements.farinha.checked?[{id:'farinha',opcao:'500g',quantidade:1}]:[])
  ];
  const option=item=>produtos.find(produto=>produto.id===item.id)?.opcoes.find(opcao=>opcao.id===item.opcao);
  form.addEventListener('change',()=>{document.querySelector('#combo-total').textContent=dinheiro(selecionados().reduce((sum,item)=>sum+option(item).preco,0));status.textContent='';});
  form.addEventListener('submit',event=>{
   event.preventDefault();
   try{
    const raw=JSON.parse(localStorage.getItem(chave)||'[]');const carrinho=[];
    if(Array.isArray(raw)) raw.forEach(item=>{
     if(!item||!option(item)||!Number.isInteger(item.quantidade)||item.quantidade<1||item.quantidade>99)return;
     const existente=carrinho.find(linha=>linha.id===item.id&&linha.opcao===item.opcao);
     if(existente)existente.quantidade=Math.min(99,existente.quantidade+item.quantidade);else carrinho.push({id:item.id,opcao:item.opcao,quantidade:item.quantidade});
    });
    const novos=selecionados();
    if(novos.some(item=>carrinho.some(linha=>linha.id===item.id&&linha.opcao===item.opcao&&linha.quantidade>=99))){status.textContent='O limite é de 99 unidades por medida. Ajuste seu carrinho para continuar.';return;}
    novos.forEach(item=>{const existente=carrinho.find(linha=>linha.id===item.id&&linha.opcao===item.opcao);if(existente)existente.quantidade++;else carrinho.push(item);});
    localStorage.setItem(chave,JSON.stringify(carrinho));
    // O evento também atualiza o estado do script compartilhado nesta aba.
    window.dispatchEvent(new StorageEvent('storage',{key:chave,newValue:JSON.stringify(carrinho)}));
    status.textContent='Combinação adicionada! Você pode conferir e ajustar no carrinho.';
    const link=document.createElement('a');link.href='paginas/carrinho.html';link.className='text-link';link.textContent='Ver meu carrinho';status.append(' ',link);
   }catch{status.textContent='O navegador não permitiu salvar a combinação. Abra o cardápio e adicione os produtos por lá.';}
  });
 }
 // Revelação única, sem esconder conteúdo quando não há suporte.
 if('IntersectionObserver' in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
  const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('reveal');observer.unobserve(entry.target);}}),{threshold:.12});
  document.querySelectorAll('.home-product,.story-copy,.ritual-grid article').forEach(el=>observer.observe(el));
 }
})();
