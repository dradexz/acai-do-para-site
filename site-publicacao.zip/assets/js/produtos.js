/* Array de objetos: três produtos, com suas opções e valores em centavos. */
window.PRODUTOS = [
    { id:'acai', nome:'Açaí do Pará', categoria:'acai', cor:'purple', simbolo:'●', descricao:'Açaí puro, com a textura e o sabor da tradição paraense.', opcoes:[
        { id:'500ml', medida:'Meio litro (500 ml)', preco:1000 },
        { id:'1l', medida:'1 litro', preco:2000 }
    ] },
    { id:'tapioca', nome:'Farinha de tapioca', categoria:'acompanhamento', cor:'gold', simbolo:'✦', descricao:'Leve e crocante: a farinha de tapioca que combina com açaí.', opcoes:[
        { id:'pacote', medida:'1 pacote (tamanho único)', preco:200 }
    ] },
    { id:'farinha', nome:'Farinha lavada', categoria:'acompanhamento', cor:'green', simbolo:'≋', descricao:'Farinha de mandioca para dar textura à sua combinação.', opcoes:[
        { id:'500g', medida:'Meio quilo (500 g)', preco:500 },
        { id:'1kg', medida:'1 quilo', preco:1000 }
    ] }
];
