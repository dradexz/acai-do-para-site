/* Interações da vitrine: carrinho e contato demonstrativos. */
(() => {
 'use strict';
 const produtos = window.PRODUTOS;
 const chave = 'acai-do-para-carrinho-v3';
 const dinheiro = valor => (valor / 100).toLocaleString('pt-BR', {style:'currency', currency:'BRL'});
 const achar = (id, opcaoId) => {
  const produto = produtos.find(item => item.id === id);
  const opcao = produto?.opcoes.find(item => item.id === opcaoId);
  return produto && opcao ? {produto, opcao} : null;
 };
 const quantidadeValida = valor => Number.isInteger(valor) && valor >= 1 && valor <= 99;
 // Valida dados recuperados do navegador antes de usá-los.
 function normalizar(dados) {
  if (!Array.isArray(dados)) return [];
  const resultado = [];
  dados.forEach(item => {
   if (!item || !achar(item.id, item.opcao) || !quantidadeValida(item.quantidade)) return;
   const existente = resultado.find(linha => linha.id === item.id && linha.opcao === item.opcao);
   if (existente) existente.quantidade = Math.min(99, existente.quantidade + item.quantidade);
   else resultado.push({id:item.id, opcao:item.opcao, quantidade:item.quantidade});
  });
  return resultado;
 }
 let carrinho = [];
 let armazenamentoDisponivel = true;
 try { carrinho = normalizar(JSON.parse(localStorage.getItem(chave) || '[]')); }
 catch { armazenamentoDisponivel = false; }
 function avisar(mensagem) {
  const toast = document.querySelector('#toast');
  toast.textContent = mensagem;
  toast.classList.add('visible');
  clearTimeout(avisar.timer);
  avisar.timer = setTimeout(() => toast.classList.remove('visible'), 4000);
 }
 function contar() { return carrinho.reduce((soma,item) => soma + item.quantidade, 0); }
 function total() { return carrinho.reduce((soma,item) => soma + achar(item.id,item.opcao).opcao.preco * item.quantidade, 0); }
 function atualizarContador() { document.querySelectorAll('[data-cart-count]').forEach(el => el.textContent = contar()); }
 function salvar() {
  try { localStorage.setItem(chave, JSON.stringify(carrinho)); }
  catch { armazenamentoDisponivel = false; avisar('O navegador bloqueou o armazenamento. O carrinho vale apenas nesta página.'); }
  atualizarContador();
 }
 document.documentElement.classList.add('js');
 const menuButton = document.querySelector('.menu-toggle');
 const menu = document.querySelector('#menu');
 menuButton.hidden = false;
 menuButton.addEventListener('click', () => {
  const aberto = menuButton.getAttribute('aria-expanded') !== 'true';
  menuButton.setAttribute('aria-expanded', String(aberto));
  menu.classList.toggle('open', aberto);
 });
 menu.addEventListener('keydown', event => {
  if (event.key === 'Escape') { menu.classList.remove('open'); menuButton.setAttribute('aria-expanded','false'); menuButton.focus(); }
 });
 atualizarContador();
 if (!armazenamentoDisponivel) avisar('Armazenamento indisponível. O carrinho pode não ser mantido entre páginas.');

 // Catálogo: filtro, busca, medidas e inclusão no carrinho.
 const catalogo = document.querySelector('#catalogo');
 if (catalogo) {
  document.querySelector('.catalog-tools').hidden = false;
  let filtro = 'todos';
  const busca = document.querySelector('#busca');
  const simplificar = texto => texto.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  function renderizarCatalogo() {
   const termo = simplificar(busca.value.trim());
   const visiveis = produtos.filter(produto => (filtro === 'todos' || produto.categoria === filtro) && simplificar(produto.nome).includes(termo));
   document.querySelector('#resultados').textContent = `${visiveis.length} produto${visiveis.length === 1 ? '' : 's'} encontrado${visiveis.length === 1 ? '' : 's'}.`;
   catalogo.innerHTML = visiveis.length ? visiveis.map(produto => `
    <article class="product-card" data-product="${produto.id}">
     <div class="product-visual ${produto.cor}"><small>${produto.categoria === 'acai' ? 'DO PARÁ' : 'ACOMPANHAMENTO'}</small><img src="../assets/imagens/${produto.id === 'acai' ? 'acai-paraense.jpg' : produto.id === 'tapioca' ? 'tapioca-braganca.jpg' : 'farinha-paraense.jpg'}" alt="${produto.id === 'acai' ? 'Açaí puro servido em uma tigela' : produto.id === 'tapioca' ? 'Farinha de tapioca de Bragança, Pará' : 'Farinha de mandioca em uma cuia, com açaí ao fundo'}" width="600" height="450" loading="lazy"></div>
     <div class="product-body"><h2>${produto.nome}</h2><p>${produto.descricao}</p><label for="medida-${produto.id}">Medida</label><select id="medida-${produto.id}" data-option>${produto.opcoes.map(opcao => `<option value="${opcao.id}">${opcao.medida}</option>`).join('')}</select><strong class="product-price" data-price>${dinheiro(produto.opcoes[0].preco)}</strong><div class="buy-row"><div><label for="qtd-${produto.id}">Qtd.</label><input type="number" id="qtd-${produto.id}" min="1" max="99" step="1" value="1" data-quantity></div><button type="button" class="button" data-add aria-label="Adicionar ${produto.nome} ao carrinho">Adicionar +</button></div></div>
    </article>`).join('') : '<p class="notice">Nenhum produto encontrado. Tente outro nome ou filtro.</p>';
  }
  document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => {
   filtro = button.dataset.filter;
   document.querySelectorAll('[data-filter]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
   renderizarCatalogo();
  }));
  busca.addEventListener('input',renderizarCatalogo);
  catalogo.addEventListener('change', event => {
   if (!event.target.matches('[data-option]')) return;
   const card = event.target.closest('[data-product]');
   card.querySelector('[data-price]').textContent = dinheiro(achar(card.dataset.product,event.target.value).opcao.preco);
  });
  catalogo.addEventListener('click', event => {
   const button = event.target.closest('[data-add]');
   if (!button) return;
   const card = button.closest('[data-product]');
   const input = card.querySelector('[data-quantity]');
   const qtd = Number(input.value);
   input.setCustomValidity('');
   if (!quantidadeValida(qtd)) { input.setCustomValidity('Informe uma quantidade inteira de 1 a 99.'); input.reportValidity(); input.focus(); return; }
   const id = card.dataset.product;
   const opcao = card.querySelector('[data-option]').value;
   const existente = carrinho.find(item => item.id === id && item.opcao === opcao);
   if (existente && existente.quantidade + qtd > 99) { avisar('O limite é de 99 unidades por medida no carrinho.'); return; }
   if (existente) existente.quantidade += qtd;
   else carrinho.push({id, opcao, quantidade:qtd});
   salvar();
   avisar(`${achar(id,opcao).produto.nome} adicionado ao carrinho.`);
  });
  catalogo.addEventListener('input', event => { if (event.target.matches('[data-quantity]')) event.target.setCustomValidity(''); });
  renderizarCatalogo();
 }

 // Carrinho: total em centavos, edição de quantidade, remoção e resumo.
 const cartItems = document.querySelector('#cart-items');
 function renderizarCarrinho() {
  if (!cartItems) return;
  cartItems.innerHTML = carrinho.length ? carrinho.map((item,index) => {
   const {produto,opcao} = achar(item.id,item.opcao);
   return `<article class="cart-item"><div><h2>${produto.nome}</h2><p>${opcao.medida} · ${dinheiro(opcao.preco)} por unidade</p><label for="cart-qtd-${index}">Quantidade</label><input id="cart-qtd-${index}" type="number" min="1" max="99" step="1" value="${item.quantidade}" data-cart-quantity="${index}" aria-label="Quantidade de ${produto.nome}, ${opcao.medida}"></div><div class="cart-item-price"><strong>${dinheiro(opcao.preco * item.quantidade)}</strong><button type="button" class="text-button" data-remove="${index}" aria-label="Remover ${produto.nome}, ${opcao.medida}">Remover</button></div></article>`;
  }).join('') : '<div class="empty-cart"><h2>Seu carrinho está vazio.</h2><p>Comece com o açaí e escolha seus acompanhamentos.</p><a class="button" href="produtos.html">Explorar produtos</a></div>';
  document.querySelector('#summary-count').textContent = contar();
  document.querySelector('#summary-total').textContent = dinheiro(total());
  document.querySelector('#copy-cart').disabled = !carrinho.length;
  document.querySelector('#clear-cart').disabled = !carrinho.length;
  document.querySelector('#copy-fallback').hidden = true;
  document.querySelector('#cart-message').textContent = '';
 }
 if (cartItems) {
  // Atualiza valores durante a edição, sem recriar o campo e perder o foco.
  cartItems.addEventListener('input', event => {
   if (!event.target.matches('[data-cart-quantity]')) return;
   const index = Number(event.target.dataset.cartQuantity);
   const qtd = Number(event.target.value);
   if (!quantidadeValida(qtd)) return;
   carrinho[index].quantidade = qtd;
   salvar();
   const item = carrinho[index];
   event.target.closest('.cart-item').querySelector('.cart-item-price strong').textContent = dinheiro(achar(item.id,item.opcao).opcao.preco * qtd);
   document.querySelector('#summary-count').textContent = contar();
   document.querySelector('#summary-total').textContent = dinheiro(total());
   document.querySelector('#copy-fallback').hidden = true;
   document.querySelector('#cart-message').textContent = '';
  });
  cartItems.addEventListener('change', event => {
   if (!event.target.matches('[data-cart-quantity]')) return;
   const index = Number(event.target.dataset.cartQuantity);
   const qtd = Number(event.target.value);
   if (!quantidadeValida(qtd)) { event.target.value = carrinho[index].quantidade; avisar('Informe uma quantidade inteira de 1 a 99.'); return; }
   carrinho[index].quantidade = qtd;
   salvar(); renderizarCarrinho();
   document.querySelector(`#cart-qtd-${index}`)?.focus();
   avisar('Quantidade e total atualizados.');
  });
  cartItems.addEventListener('click', event => {
   const button = event.target.closest('[data-remove]');
   if (!button) return;
   const index = Number(button.dataset.remove);
   carrinho.splice(index,1); salvar(); renderizarCarrinho();
   const proximo = cartItems.querySelector(`[data-remove="${Math.min(index,carrinho.length-1)}"]`) || cartItems.querySelector('a');
   proximo?.focus(); avisar('Produto removido.');
  });
  document.querySelector('#clear-cart').addEventListener('click', () => { carrinho = []; salvar(); renderizarCarrinho(); cartItems.querySelector('a')?.focus(); avisar('Carrinho limpo.'); });
  document.querySelector('#copy-cart').addEventListener('click', async () => {
   const texto = ['Açaí do Pará — resumo demonstrativo', ...carrinho.map(item => { const {produto,opcao}=achar(item.id,item.opcao); return `${item.quantidade} × ${produto.nome} — ${opcao.medida}: ${dinheiro(opcao.preco * item.quantidade)}`; }), `Total: ${dinheiro(total())}`, 'Simulação acadêmica. Nenhum pedido foi enviado.'].join('\n');
   try { if (!navigator.clipboard) throw new Error('Clipboard indisponível'); await navigator.clipboard.writeText(texto); document.querySelector('#cart-message').textContent = 'Resumo copiado! Nenhum pedido foi enviado.'; }
   catch { document.querySelector('#copy-fallback').hidden = false; const textarea = document.querySelector('#resumo-texto'); textarea.value=texto; textarea.focus(); textarea.select(); document.querySelector('#cart-message').textContent = 'Copie o texto selecionado com Ctrl+C ou com o menu do celular.'; }
  });
  renderizarCarrinho();
 }
 window.addEventListener('storage', event => { if (event.key !== chave && event.key !== null) return; try { carrinho=normalizar(JSON.parse(localStorage.getItem(chave)||'[]')); atualizarContador(); renderizarCarrinho(); } catch { /* Mantém o carrinho atual se o armazenamento estiver bloqueado. */ } });

 // Validação de formulário com feedback junto a cada campo.
 const form = document.querySelector('#contact-form');
 if (form) {
  form.noValidate = true;
  document.querySelector('#contact-submit').disabled = false;
  const campos = ['nome','email','telefone','assunto','mensagem'];
  const status = document.querySelector('#form-status');
  const contador = document.querySelector('#contador');
  function erro(id) {
   const campo = document.getElementById(id);
   const valor = campo.value.trim();
   if (id === 'nome' && (valor.length < 2 || valor.length > 80)) return 'Informe um nome entre 2 e 80 caracteres.';
   if (id === 'email' && (!valor || campo.validity.typeMismatch || valor.length > 120 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valor))) return 'Informe um e-mail válido, como nome@exemplo.com.';
   if (id === 'telefone' && valor && (!/^[+\d\s().-]+$/.test(valor) || ![10,11,12,13].includes(valor.replace(/\D/g,'').length))) return 'Informe DDD e número; o código do país é opcional.';
   if (id === 'assunto' && !['acai','tapioca','farinha-lavada','geral'].includes(valor)) return 'Selecione um assunto.';
   if (id === 'mensagem' && (valor.length < 10 || valor.length > 1000)) return 'Escreva uma mensagem entre 10 e 1000 caracteres.';
   return '';
  }
  function validar(id) {
   const mensagem = erro(id);
   const campo = document.getElementById(id);
   campo.setAttribute('aria-invalid',String(Boolean(mensagem)));
   document.getElementById(`erro-${id}`).textContent = mensagem;
   return !mensagem;
  }
  campos.forEach(id => {
   const campo = document.getElementById(id);
   campo.addEventListener('blur', () => validar(id));
   campo.addEventListener('input', () => { if (campo.hasAttribute('aria-invalid')) validar(id); status.textContent=''; status.classList.remove('error'); });
   campo.addEventListener('change', () => { if (campo.hasAttribute('aria-invalid')) validar(id); });
  });
  document.querySelector('#mensagem').addEventListener('input', event => { contador.textContent = `${event.target.value.length} / 1000`; });
  form.addEventListener('submit', event => {
   event.preventDefault();
   const invalidos = campos.filter(id => !validar(id));
   status.classList.toggle('error',Boolean(invalidos.length));
   if (invalidos.length) { status.textContent='Confira os campos indicados antes de continuar.'; document.getElementById(invalidos[0]).focus(); return; }
   status.textContent='Mensagem validada com sucesso! Esta é uma demonstração: os dados não foram enviados nem armazenados.';
  });
  form.addEventListener('reset', () => { campos.forEach(id => { document.getElementById(id).removeAttribute('aria-invalid'); document.getElementById(`erro-${id}`).textContent=''; }); status.textContent=''; status.classList.remove('error'); contador.textContent='0 / 1000'; });
 }
})();
